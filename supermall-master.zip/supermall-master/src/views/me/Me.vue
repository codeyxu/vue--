<template>
    <h2>关于我</h2>
</template>

<script>
    export default {
        name: "Me"
    }
</script>

<style scoped>

</style>
