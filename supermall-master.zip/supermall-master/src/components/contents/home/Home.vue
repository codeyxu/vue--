<template>
    <div>
      <MainTarBar></MainTarBar>
    </div>
</template>

<script>
  import MainTarBar from 'components/contents/maintarbar/MainTarBar'
  export default {
      name: "Home",
      components: {
          MainTarBar
      }
  }
</script>

<style scoped>

</style>
